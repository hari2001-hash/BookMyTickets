# movie-seat-booking

Live Project View : https://movie-seat-booking-2021.netlify.app/

Page One
![alt text](https://i.ibb.co/PCJk7Gc/screencapture-movie-seat-booking-2021-netlify-app-playing-html-2021-02-20-15-10-33.png)

Page Two
![alt text](https://i.ibb.co/nPf0HM6/screencapture-movie-seat-booking-2021-netlify-app-booking-html-2021-02-20-15-10-05.png)

Page Three
![alt text](https://i.ibb.co/gS51gCY/screencapture-movie-seat-booking-2021-netlify-app-2021-02-20-15-10-20.png)
